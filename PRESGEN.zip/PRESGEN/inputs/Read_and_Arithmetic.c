// The programs reads two integers and performs various arithmetic 
// operations on them.

#include <stdio.h>

void main ()
{
    int a, b, c, d;
    scanf ("%d", &a);
    scanf ("%d", &b);
    
    c = a + b;
    d = a - b;
    d = c * d;
    
    printf ("%d", d);
}

