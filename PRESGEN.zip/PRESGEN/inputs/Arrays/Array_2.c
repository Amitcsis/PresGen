#include <stdio.h>

void main ()
{
    int a1[10], a2[20], i, j;
    
    for (i = 0; i < 10; i++)
        a1[i] = 0;
    
    printf ("%d", i);
    
    for (j = 0; j < 20; j++)
        a2[j] = 0;
}
