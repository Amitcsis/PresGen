#include <stdio.h>

void main ()
{
    int i, n, a;
    
    scanf ("%d", &n);

    for (i = 0; i < n; i++)
        a = 10;
    
    printf ("%d", i);
    scanf ("%d", &n);
    
    for (i = 0; i < n; i++)
        a = 20;
    
    printf ("%d", i);
}
