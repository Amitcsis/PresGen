#include <stdio.h>

void main () {
    int a, b, c, d;
    scanf ("%d", &a);
    while (a < 100) {
        a += 1;
        if (a > 50) {
            scanf ("%d", &b);
            printf ("%d", b);
            if (b > 50)
                a += 3;
        }
        else 
            a += 2;
    }
}