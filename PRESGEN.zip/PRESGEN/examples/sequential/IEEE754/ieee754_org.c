void main ()
{
	int actualMantissa;
	int input1;
	int sign1;
	int mantissa1;
	int TWO_RAISED_23;
	int exponent1;
	int TWO_RAISED_24;
	int input2;
	int sign2;
	int mantissa2;
	int exponent2;
	int option;
	int diff;
	int exponent;
	int mantissa;
	int sign;
	int value;
	int condtemp;
	int mantissa_mult;
	int TWO_RAISED_46;
	int temp2;
	int characteristic;
	int length;
	int temp3;
	int temp4;
	int temp6;
	int temp5;
	int TWO_RAISED_31;
	int temp7;
	int temp8;
	int temp9;
	int temp10;
	int result;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  q00:
		actualMantissa=0;
		goto q01;
  q01:

	if (input1<0)
 	{
		sign1=1;
		goto q02;
	}

	else
 	{
		sign1=0;
		goto q02;
	}
  q02:
		mantissa1=input1%TWO_RAISED_23;
		exponent1=input1*2;
		goto q03;
  q03:
		mantissa1=mantissa1+TWO_RAISED_23;
		exponent1=exponent1/TWO_RAISED_24;
		goto q04;
  q04:

	if (input2<0)
 	{
		sign2=1;
		goto q05;
	}

	else
 	{
		sign2=0;
		goto q05;
	}
  q05:
		mantissa2=input2%TWO_RAISED_23;
		exponent2=input2*2;
		goto q06;
  q06:
		mantissa2=mantissa2+TWO_RAISED_23;
		exponent2=exponent2/TWO_RAISED_24;
		goto q07;
  q07:

	if (option==1)
 	{
		goto q08;
	}

	else if (option==2)
 	{
		goto q08;
	}

	else if (! (option==1) )
 	{
		goto q025;
	}

	else
 	{
		goto q025;
	}
  q08:
		diff=exponent1-exponent2;
		goto q09;
  q09:

	if (diff>0)
 	{
		goto q010;
	}

	else
 	{
		goto q011;
	}
  q010:

	if (diff>0)
 	{
		mantissa2=mantissa2/2;
		diff=diff-1;
		goto q010;
	}

	else
 	{
		exponent=exponent1;
		goto q013;
	}
  q011:

	if (diff<0)
 	{
		goto q012;
	}

	else
 	{
		exponent=exponent1;
		goto q013;
	}
  q012:

	if (diff<0)
 	{
		mantissa1=mantissa1/2;
		diff=diff+1;
		goto q012;
	}

	else
 	{
		exponent=exponent2;
		goto q013;
	}
  q013:

	if (sign1==1)
 	{
		mantissa1=-mantissa1;
		goto q014;
	}

	else
 	{
		goto q014;
	}
  q014:

	if (sign2==1)
 	{
		mantissa2=-mantissa2;
		goto q015;
	}

	else
 	{
		goto q015;
	}
  q015:

	if (option==1)
 	{
		mantissa=mantissa1+mantissa2;
		goto q016;
	}

	else
 	{
		mantissa=mantissa1-mantissa2;
		goto q016;
	}
  q016:
		sign=0;
		goto q017;
  q017:

	if (mantissa<0)
 	{
		sign=1;
		mantissa=-mantissa;
		goto q018;
	}

	else
 	{
		goto q018;
	}
  q018:
		value=mantissa/TWO_RAISED_23;
		goto q019;
  q019:
		value=value%4;
		goto q020;
  q020:

	if (value==0)
 	{
		goto q021;
	}

	else
 	{
		goto q023;
	}
  q021:
		condtemp=mantissa/TWO_RAISED_23;
		goto q054;
  q054:
		condtemp=condtemp%4;
		goto q022;
  q022:

	if (exponent!=0&&condtemp!=1)
 	{
		mantissa=mantissa*2;
		exponent=exponent-1;
		goto q021;
	}

	else
 	{
		goto q025;
	}
  q023:

	if (value==2)
 	{
		mantissa=mantissa/2;
		exponent=exponent+1;
		goto q025;
	}

	else
 	{
		goto q024;
	}
  q024:

	if (value==3)
 	{
		mantissa=mantissa/2;
		exponent=exponent+1;
		goto q025;
	}

	else
 	{
		goto q025;
	}
  q025:

	if (option==3)
 	{
		goto q026;
	}

	else
 	{
		goto q037;
	}
  q026:

	if (sign1==sign2)
 	{
		sign=0;
		goto q027;
	}

	else
 	{
		sign=1;
		goto q027;
	}
  q027:
		exponent=exponent1+exponent2;
		mantissa_mult=mantissa1*mantissa2;
		goto q028;
  q028:
		exponent=exponent-127;
		value=mantissa_mult/TWO_RAISED_46;
		goto q029;
  q029:
		value=value%4;
		goto q030;
  q030:

	if (value==0)
 	{
		goto q031;
	}

	else
 	{
		goto q033;
	}
  q031:
		temp2=mantissa_mult/TWO_RAISED_46;
		goto q053;
  q053:
		temp2=temp2%4;
		goto q032;
  q032:

	if (exponent!=0&&temp2!=1)
 	{
		exponent=exponent-1;
		mantissa_mult=mantissa_mult*2;
		goto q031;
	}

	else
 	{
		goto q035;
	}
  q033:

	if (value==2)
 	{
		mantissa_mult=mantissa_mult/2;
		exponent=exponent+1;
		goto q035;
	}

	else
 	{
		goto q034;
	}
  q034:

	if (value==3)
 	{
		mantissa_mult=mantissa_mult/2;
		exponent=exponent+1;
		goto q035;
	}

	else
 	{
		goto q035;
	}
  q035:
		mantissa=mantissa_mult/TWO_RAISED_23;
		goto q036;
  q036:
		mantissa=mantissa%TWO_RAISED_23;
		goto q037;
  q037:

	if (option==4)
 	{
		goto q038;
	}

	else
 	{
		goto q049;
	}
  q038:

	if (sign1==sign2)
 	{
		sign=0;
		goto q039;
	}

	else
 	{
		sign=1;
		goto q039;
	}
  q039:
		diff=exponent1-exponent2;
		goto q040;
  q040:

	if (diff>0)
 	{
		goto q041;
	}

	else
 	{
		goto q042;
	}
  q041:

	if (diff>0)
 	{
		mantissa2=mantissa2/2;
		diff=diff-1;
		goto q041;
	}

	else
 	{
		goto q044;
	}
  q042:

	if (diff<0)
 	{
		goto q043;
	}

	else
 	{
		goto q044;
	}
  q043:

	if (diff<0)
 	{
		mantissa1=mantissa1/2;
		diff=diff+1;
		goto q043;
	}

	else
 	{
		goto q044;
	}
  q044:
		exponent=0;
		mantissa=mantissa1/mantissa2;
		characteristic=diff;
		length=32;
		goto q045;
  q045:

	if (mantissa!=1)
 	{
		exponent=exponent+1;
		temp3=mantissa%2;
		temp4=actualMantissa/2;
		goto q046;
	}

	else
 	{
		exponent=exponent+127;
		temp6=actualMantissa/512;
		goto q048;
	}
  q046:
		temp5=temp3*TWO_RAISED_31;
		mantissa=mantissa/2;
		goto q047;
  q047:
		actualMantissa=temp5+temp4;
		goto q045;
  q048:
		mantissa=TWO_RAISED_23+temp6;
		goto q049;
  q049:
		temp7=exponent*TWO_RAISED_23;
		temp8=sign*TWO_RAISED_31;
		goto q050;
  q050:
		temp9=temp7+temp8;
		temp10=mantissa%TWO_RAISED_23;
		goto q051;
  q051:
		result=temp9+temp10;
		goto q052;
  q052:
	;
}
