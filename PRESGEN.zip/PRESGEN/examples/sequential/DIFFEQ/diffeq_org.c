void main ()
{
	int i;
	int x;
	int a;
	int xout;
	int t1;
	int u;
	int dx;
	int t2;
	int t3;
	int y;
	int t4;
	int t5;
	int t6;
	int y1;
	int yout;
	int uout;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
  q00:
		i=0;
		goto q01;
  q01:

	if (! (x<a) )
 	{
		xout=x;
		goto q013;
	}

	else
 	{
		t1=u*dx;
		goto q02;
	}
  q02:
		t2=x*3;
		goto q03;
  q03:
		t3=y*3;
		goto q04;
  q04:
		t4=t1*t2;
		goto q05;
  q05:
		t5=dx*t3;
		goto q06;
  q06:
		t6=u-t4;
		goto q07;
  q07:
		u=t6-t5;
		goto q08;
  q08:
		y1=u*dx;
		goto q09;
  q09:
		y=y+y1;
		goto q010;
  q010:
		x=x+dx;
		goto q011;
  q011:
		i=i+1;
		goto q01;
  q013:
		yout=y;
		goto q014;
  q014:
		uout=u;
		goto q015;
  q015:
	;
}
