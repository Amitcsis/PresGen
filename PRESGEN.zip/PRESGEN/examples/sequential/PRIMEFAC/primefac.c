#include <stdio.h>

void main()
/* To Find the Prime Factors of a number */
{
    int num;

    // printf("\nEnter the Number:");
    scanf("%d",&num);
    printf("\nThe Prime Factors of %d =",num);

    int k,m;
    while(num > 1)
    {
        for(k = 2; k <= num; k++)
        {
            m = num % k;
            if(m == 0)
            {
                printf("%d,",k);
                num = num / k;
                break;
            }
        }
    }

    // printf("\n");
    
}








